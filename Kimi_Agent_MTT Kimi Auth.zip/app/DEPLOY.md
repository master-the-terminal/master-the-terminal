# Deploy Master The Terminal to Hostinger Cloud Startup

**ZIP file is ready.** Download `deploy.zip` below. It contains the pre-built application — upload it to Hostinger and set your environment variables. Done.

---

## What Is In The ZIP

- **Frontend**: React 19 + Vite + Tailwind CSS + shadcn/ui (`src/`, built to `dist/public/`)
- **Backend**: Hono + tRPC + Drizzle ORM (`api/`, bundled to `dist/boot.js`)
- **Database**: MySQL via Drizzle ORM
- **Auth**: Kimi OAuth 2.0
- **Build output**: `dist/boot.js` (backend) + `dist/public/` (frontend)
- **Package files**: `package.json` + `package-lock.json` (Hostinger runs `npm install`)

The app boots from a single file: `dist/boot.js`. It serves the frontend from `dist/public/` and handles API calls at `/api/trpc/*`.

---

## Step 1: Buy Hostinger Cloud Startup

1. Go to [hostinger.com](https://www.hostinger.com)
2. Select **Cloud Startup** plan
3. Register your domain or use an existing one
4. After checkout, check your email for the **hPanel** login link
5. Log into hPanel

---

## Step 2: Create the Node.js App (Upload the ZIP)

1. In hPanel, go to **Websites > Manage > Node.js**
2. Click **Create Application**
3. Fill in these **exact** values:

| Field | Value |
|-------|-------|
| **Node.js version** | `20.x` |
| **Application mode** | `Production` |
| **Application root** | `/` |
| **Application URL** | `yourdomain.com` |
| **Application startup file** | `dist/boot.js` |
| **Framework** | **Hono** |
| **Build command** | `npm install` |
| **Start command** | `npm start` |

4. Find the **Upload Source Code** section
5. Upload `deploy.zip`
6. Click **Create**

Hostinger extracts the ZIP, runs `npm install`, then `npm start` → `node dist/boot.js`.

---

## Step 3: Create the MySQL Database

1. In hPanel, go to **Websites > Manage > Databases > Management**
2. Click **Create Database**
3. Name it `mastertheterminal`
4. Create a user with a strong password

You will get credentials like:

```
Database:   u123456789_mastertheterminal
Username:   u123456789_mastertheterminal
Password:   YourStrongPassword123!
Host:       localhost
Port:       3306
```

**Write these down.** You need them in the next step.

---

## Step 4: Set Environment Variables in hPanel

In hPanel, go to your **Node.js App > Environment Variables**. Add every single one of these (replace example values with your actual credentials from Step 3):

### Database
```
DATABASE_URL=mysql://u123456789_mastertheterminal:YourStrongPassword123!@localhost:3306/u123456789_mastertheterminal
```

### App Secrets (from your local `.env` file)
```
APP_ID=19dde6c2-6702-84fa-8000-00003a5aac91
APP_SECRET=lyIDvamxajyfS9cqhDKXvIcVkeRumlgp
```

### Frontend OAuth
```
VITE_APP_ID=19dde6c2-6702-84fa-8000-00003a5aac91
VITE_KIMI_AUTH_URL=https://auth.kimi.com
```

### Backend OAuth
```
KIMI_AUTH_URL=https://auth.kimi.com
KIMI_OPEN_URL=https://open.kimi.com
```

### Admin
```
OWNER_UNION_ID=d7l3fttgsoa7ilc80ojg
```

### Production flag
```
NODE_ENV=production
```

Click **Save**, then click **Restart**.

> **Do NOT commit `.env` to Git.** Hostinger's environment variable manager stores secrets securely.

---

## Step 5: Create the Database Tables

This app uses Drizzle ORM. The tables do not exist yet on your Hostinger MySQL.

Run this from your local machine:

```bash
# Temporarily point at Hostinger MySQL
export DATABASE_URL="mysql://u123456789_mastertheterminal:YourStrongPassword123!@localhost:3306/u123456789_mastertheterminal"

# Push the schema — creates all tables
npx drizzle-kit push
```

### Verify it worked

1. Open **phpMyAdmin** in hPanel
2. You should see tables: `courses`, `lessons`, `payments`, `progress`, `users`
3. If they are there, it worked

---

## Step 6: Enable SSL

1. In hPanel, go to **Websites > Manage > SSL**
2. Click **Install SSL**
3. Hostinger requests a free Let's Encrypt certificate
4. Wait 2-3 minutes

Your app is now at `https://yourdomain.com`.

---

## Step 7: Verify

| Check | How |
|-------|-----|
| Homepage loads | Visit `https://yourdomain.com` |
| API works | Visit `https://yourdomain.com/api/trpc/course.list` |
| React Router | Navigate to `/courses`, refresh — should not 404 |
| OAuth | Click **Sign in with Kimi** — should redirect and return |
| Database | Sign in, check `users` table in phpMyAdmin |

If anything fails, read **Deployment Logs** in hPanel.

---

## If It Breaks

| Error | Fix |
|-------|-----|
| `Cannot find module 'hono'` | `npm install` failed. Check Deployment Logs. |
| `Missing required environment variable: DATABASE_URL` | Add it in hPanel Environment Variables. |
| `connect ECONNREFUSED localhost:3306` | Wrong credentials, or database not created. |
| 404 on every page except `/` | `dist/public/` missing from ZIP. Rebuild locally and rezip. |
| Blank white page | API not responding. Check `VITE_APP_ID` and `VITE_KIMI_AUTH_URL` env vars. |

---

## Updating the App Later

Rebuild locally, create a new ZIP, re-upload in hPanel.

```bash
cd /path/to/this-project
npm run build
zip -r deploy.zip . -x "node_modules/*" -x ".git/*"
```

Then upload the new ZIP in hPanel **Node.js App > Source Code > Upload**.

