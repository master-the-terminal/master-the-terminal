#!/bin/bash
# Master The Terminal — Hostinger Deploy Script
#
# HOW TO USE THIS SCRIPT:
#
#   Option A: Via hPanel Terminal (easiest, no SSH needed)
#   --------------------------------------------------------
#   1. In hPanel, go to Advanced > Terminal (or Cron Jobs)
#   2. Upload this deploy.sh file via File Manager
#   3. In the terminal, run: bash deploy.sh
#
#   Option B: Via SSH (if enabled on your plan)
#   --------------------------------------------
#   1. Enable SSH in hPanel: Websites > Manage > SSH Access
#   2. Your SSH username is shown there — looks like u123456789
#   3. From your local terminal:
#
#        scp deploy.sh YOUR_USERNAME@YOUR_DOMAIN.com:~/
#        ssh YOUR_USERNAME@YOUR_DOMAIN.com
#        bash deploy.sh
#
#   YOUR_USERNAME = the SSH user shown in hPanel (e.g. u123456789)
#   YOUR_DOMAIN   = your actual domain (e.g. mastertheterminal.com)

set -e

echo "======================================"
echo "  Master The Terminal — Auto Deploy"
echo "======================================"
echo ""

# ── Detect App Directory ────────────────────────────────────
# Hostinger Node.js apps live in the domain's public_html folder
# We try to auto-detect it, or you can set APP_DIR before running

if [ -n "$APP_DIR" ]; then
    cd "$APP_DIR"
elif [ -d "$HOME/domains/$HOSTNAME/public_html" ]; then
    cd "$HOME/domains/$HOSTNAME/public_html"
elif [ -d "$HOME/public_html" ]; then
    cd "$HOME/public_html"
else
    echo "Could not auto-detect app directory."
    echo ""
    echo "Run this script with the app path:"
    echo "  APP_DIR=/home/YOUR_USER/domains/YOUR_DOMAIN/public_html bash deploy.sh"
    echo ""
    echo "To find your path, open hPanel > File Manager."
    echo "Look for the folder containing package.json and dist/"
    exit 1
fi

echo "App directory: $(pwd)"
echo ""

# ── Extract ZIP if found ────────────────────────────────────
if [ -f "deploy.zip" ]; then
    echo "[1/6] Extracting deploy.zip..."
    unzip -o deploy.zip
    rm -f deploy.zip
    echo "  Done."
fi

# ── Confirm we're in the right place ────────────────────────
if [ ! -f "package.json" ]; then
    echo "ERROR: package.json not found in $(pwd)"
    echo "Upload deploy.zip to this directory first, or run from the app root."
    exit 1
fi

# ── Get Database Credentials ────────────────────────────────
echo ""
echo "Enter your MySQL credentials from hPanel > Databases > Management:"
echo ""
read -p "  Database name (e.g. u123456789_mastertheterminal): " DB_NAME
read -p "  Database user  (e.g. u123456789_mastertheterminal): " DB_USER
read -s -p "  Database password: " DB_PASS
echo ""
echo ""

if [ -z "$DB_NAME" ] || [ -z "$DB_USER" ] || [ -z "$DB_PASS" ]; then
    echo "ERROR: All fields are required."
    exit 1
fi

# ── Write .env ──────────────────────────────────────────────
echo "[2/6] Writing .env file..."

cat > .env <<EOF
NODE_ENV=production
DATABASE_URL=mysql://${DB_USER}:${DB_PASS}@localhost:3306/${DB_NAME}
APP_ID=19dde6c2-6702-84fa-8000-00003a5aac91
APP_SECRET=lyIDvamxajyfS9cqhDKXvIcVkeRumlgp
VITE_APP_ID=19dde6c2-6702-84fa-8000-00003a5aac91
VITE_KIMI_AUTH_URL=https://auth.kimi.com
KIMI_AUTH_URL=https://auth.kimi.com
KIMI_OPEN_URL=https://open.kimi.com
OWNER_UNION_ID=d7l3fttgsoa7ilc80ojg
EOF

echo "  Done. .env written."

# ── Install Dependencies ────────────────────────────────────
echo ""
echo "[3/6] Running npm install..."
npm install --prefer-offline 2>&1 | tail -3

# ── Build if dist/ is missing ───────────────────────────────
if [ ! -f "dist/boot.js" ]; then
    echo ""
    echo "[4/6] dist/boot.js missing — running npm run build..."
    npm run build
else
    echo ""
    echo "[4/6] dist/boot.js found — skipping build."
fi

# ── Push Database Schema ────────────────────────────────────
echo ""
echo "[5/6] Creating database tables (drizzle-kit push)..."
export DATABASE_URL="mysql://${DB_USER}:${DB_PASS}@localhost:3306/${DB_NAME}"
npx drizzle-kit push

# ── Verify ──────────────────────────────────────────────────
echo ""
echo "[6/6] Verifying..."
if [ -f "dist/boot.js" ] && [ -f "dist/public/index.html" ]; then
    echo "  OK — dist/boot.js and dist/public/index.html exist."
else
    echo "  WARNING: Build output incomplete."
fi

# ── Done ────────────────────────────────────────────────────
echo ""
echo "======================================"
echo "  DEPLOY SCRIPT COMPLETE"
echo "======================================"
echo ""
echo "Now finish in hPanel:"
echo ""
echo "  1. Node.js App > Environment Variables"
echo "     Add these EXACT values:"
echo ""
echo "     NODE_ENV=production"
echo "     DATABASE_URL=mysql://${DB_USER}:${DB_PASS}@localhost:3306/${DB_NAME}"
echo "     APP_ID=19dde6c2-6702-84fa-8000-00003a5aac91"
echo "     APP_SECRET=lyIDvamxajyfS9cqhDKXvIcVkeRumlgp"
echo "     VITE_APP_ID=19dde6c2-6702-84fa-8000-00003a5aac91"
echo "     VITE_KIMI_AUTH_URL=https://auth.kimi.com"
echo "     KIMI_AUTH_URL=https://auth.kimi.com"
echo "     KIMI_OPEN_URL=https://open.kimi.com"
echo "     OWNER_UNION_ID=d7l3fttgsoa7ilc80ojg"
echo ""
echo "  2. Click SAVE, then RESTART"
echo ""
echo "  3. Websites > Manage > SSL > Install SSL"
echo ""
echo "  4. Visit https://YOUR_DOMAIN"
echo ""
echo "Done."
